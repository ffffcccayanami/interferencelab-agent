# 推理实验结果分析报告

生成时间：2026-10-21 06:19:23 UTC

## 1. 任务

**问题：** 串行验证 B：再跑一次对照

**输入：**

| 文件 | 类型 | 字节 |
|---|---|---|
| bench_concurrency_sample.json | benchmark_json | 10,933 |

## 2. 配对条件检查

- 记录数：40
- 负载组数：1
- 可对照组数：1
- 配对结果：通过
- 说明：组键 = (并发, 输入长度, 输出长度)；组键不同即视为不同负载，不做横向对比。
- 说明：分位采用 numpy 线性插值（method='linear'），与 Prometheus 直方图近似值不是同一算法。

## 3. 分组指标

| 配置 | 并发 | 输入 | 输出 | 样本 | 吞吐(tok/s) | TTFT P50(ms) | P90 | P95 | TPOT(ms) | 错误率 |
|---|---|---|---|---|---|---|---|---|---|---|
| apc | 4 | 2,800 | 128 | 20 | 108.95 | 133.00 | 141.15 | 142.07 | 31.13 | 0.00 |
| baseline | 4 | 2,800 | 128 | 20 | 74.94 | 209.98 | 218.14 | 219.06 | 45.13 | 0.00 |

## 4. 同负载对照

| 负载 | 基线 | 候选 | 吞吐 | 吞吐变化 | TTFT P50 | P50 降低 | 平均时延变化 |
|---|---|---|---|---|---|---|---|
| 并发 4 / 输入 2800 / 输出 128 | baseline | apc | 74.94 → 108.95 | 45.38% | 209.98 → 133.00 | 36.66% | -31.22% |


## 模型解释（非确定性，未参与数值计算）

本次为同环境同负载的重复对照（并发4、输入2800、输出128 token、20请求、0错误），仅含apc与baseline一组配对，配对校验通过。结果显示：apc输出吞吐108.95 tok/s，baseline为74.94，高出45.38%；TTFT p50由209.98ms降至133.0ms，降幅36.66%；平均延迟由5940.99ms降至4086.44ms，降低31.22%；TPOT均值31.13ms对45.13ms。以上为同环境同负载下apc与baseline配置对照所得差异，重复运行方向与量级可作为稳定性佐证，但不能据此断言单一参数的因果作用。

## 结论边界

- 对照收益来自**同一环境、同一负载下的配置差异**，不能把全部收益归因于单个参数；
- 分位由本仓库用 numpy 线性插值计算，与 Prometheus 直方图近似值不是同一算法；
- 未覆盖多卡张量并行、PD 分离与生产容量结论；
- 请求级指标依赖输入文件中的 ts 字段，缺少时间戳时吞吐与 TPOT 记为不可用。


## 附录：计算口径

- `output_throughput` = sum(output_tokens) / (max(end_ts) - min(start_ts))
- `ttft_ms_pXX` = numpy.percentile(ttft_ms, XX, method='linear')
- `tpot_ms_mean` = mean((end_ts - start_ts - ttft_ms/1000) / (output_tokens - 1))
- `latency_ms_mean` = mean((end_ts - start_ts) * 1000)
- `error_rate` = error_count / request_count
- `delta_pct` = (candidate - baseline) / baseline * 100
- `reduction_pct` = (baseline - candidate) / baseline * 100
