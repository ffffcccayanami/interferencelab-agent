# 受控验证报告

生成时间：2026-10-21 05:54:39 UTC

## 1. 验证项

- 条目：`bench_smoke` — 既有 benchmark 结果复算 smoke
- 脚本：`bench_smoke.py`（registry 白名单内，参数经 JSON Schema 校验）
- 退出码：0
- 耗时：124.77 ms
- 是否超时：否

## 2. 参数

```json
{
  "concurrency": 4,
  "input_tokens": 2800,
  "output_tokens": 128,
  "repeats": 2
}
```

## 3. 标准输出

```text
{"note": "确定性复算，仅验证链路；不代表模型性能。", "ok": true, "prefill_decode_ratio": 21.875, "requests": 8, "sqrt_requests": 2.8284, "total_tokens": 23424}
```

## 结论边界

- 只执行 registry 中登记且经人工确认的脚本，不接受任意命令或路径；
- 脚本在独立任务目录中运行，环境变量白名单不包含任何 API Key；
- 验证结果仅代表该脚本的固定检查，不代表整模型或生产环境结论。
